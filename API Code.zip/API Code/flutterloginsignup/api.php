<?php
include('crud.php');
header("Access-Control-Allow-Origin: *");
// $name = $_POST['name'];

// echo"Registeration of $name";

$user = new User();

if (isset($_GET['sign'])) {

    $email = $_POST['email'];
    $password = $_POST['password'];
    $user->CreateUser($email, $password);
} elseif (isset($_GET['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $user->GetUser($email,$password);
}
