<?php
include("connect.php");

class User
{

    public function CreateUser($email, $password)
    {
        global $connect;
        $query = "insert into user VALUES (NULL,'$email', '$password')";
        $result = mysqli_query($connect, $query);
        echo $query;
        echo $result;
        echo json_encode($result);
    }


    public function GetUser($email, $password)
    {
        global $connect;
        $query = "select * from user WHERE email= '$email' and password ='$password'";
        $result = mysqli_query($connect, $query);
        if (mysqli_num_rows($result) > 0) {
            $i = 0;
            $data = array();
            while($row = mysqli_fetch_assoc($result)){
                $data[$i]= $row;
                $i++;
            }
            echo json_encode($data, JSON_PRETTY_PRINT);
        }else{
            echo "Failed";
        }
    }


    public function DeleteUser()
    {


        return null;
    }


    public function ViewUser()
    {


        return null;
    }
}
